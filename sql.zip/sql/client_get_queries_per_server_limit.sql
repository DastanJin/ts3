select * from clients where server_id=:server_id: and client_login_name like :pattern: limit :duration: offset :start:;
